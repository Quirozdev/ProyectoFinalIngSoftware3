package Base;

public interface Respondible<T, V> {

    public T getSelectedRespuesta();

    public void setSelectedRespuesta(V respuesta);
}
